package com.textonphoto.customqoutescreator.utility;

public interface UpdateQuotesListInterface {
    void updateAdapter();
}
