package com.textonphoto.customqoutescreator.interfacelistner;

public interface OnGetImgBackgndSelect {
    void ongetImageBitmap(String str);
}
