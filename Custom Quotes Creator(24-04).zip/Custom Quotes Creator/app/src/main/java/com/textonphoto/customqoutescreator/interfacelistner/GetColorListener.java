package com.textonphoto.customqoutescreator.interfacelistner;

public interface GetColorListener {
    void onColor(int i, String str);
}
