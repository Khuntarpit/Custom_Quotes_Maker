package com.textonphoto.customqoutescreator;

import android.os.Environment;

import java.io.File;

public class APPUtility {

    final static public String Account_name = "Khunt Brothers";
    final static public String PrivacyPolicy = "https://www.google.com/";
	
	 public static File getAppDir() {
        return Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM);
    }
}

