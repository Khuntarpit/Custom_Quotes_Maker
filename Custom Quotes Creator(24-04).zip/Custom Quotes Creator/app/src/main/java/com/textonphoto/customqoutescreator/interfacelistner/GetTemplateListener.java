package com.textonphoto.customqoutescreator.interfacelistner;

public interface GetTemplateListener {
    void ontemplate(int i);
}
