package com.textonphoto.customqoutescreator.interfacelistner;

public interface OnGetBackgroundReworded {
    void ongetBackgroundReworded(String str, String str2, String str3);
}
