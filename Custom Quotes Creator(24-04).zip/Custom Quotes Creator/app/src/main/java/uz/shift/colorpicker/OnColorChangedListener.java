package uz.shift.colorpicker;

public interface OnColorChangedListener {
    void onColorChanged(int c);
}
